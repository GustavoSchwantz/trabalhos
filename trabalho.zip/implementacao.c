#include <stdio.h>
#include <stdlib.h>

#define TAM 100

int RandVetor(int * vetor);
int PrintVetor(int vetor[]);
int ordena_ (int * vetor, int *n);

int main(int argc, char **argv)
{
	int vetor[TAM];
    int n = TAM;

	RandVetor (vetor);

    PrintVetor (vetor);
	ordena_ (vetor, &n);
	PrintVetor (vetor);

	return 0;
}

int RandVetor(int * vetor){
	int i=0;
	srand(1000);
    for(i = 0; i < TAM; i++){
		vetor[i] = rand()% 1000;
		//printf("O valor gerado foi: %d \n",vetor[i]);
    }
	return 0;
}

int PrintVetor(int * vetor){
	int i = 0;
	printf("Vetor:\n");
	for (i = 0; i < TAM; i++)
	{
		printf("Posição %d: %d\n", i+1, vetor[i]);
	}
	return 0;
}
