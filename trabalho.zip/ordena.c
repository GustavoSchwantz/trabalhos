int ordena_ (int * vetor, int *n) {
	int aux = 0;	
	for (int i = 0; i < *n; i++){
		for (int j = 0; j < *n; j++){
			if (vetor[i] < vetor[j]){
				aux = vetor[i];
                vetor[i] = vetor[j];
                vetor[j] = aux;
            }
        }
    }

    return 0;
}
