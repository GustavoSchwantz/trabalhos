#include "functions.h"

void insertion_sort (LIST *l)
{
	if (l->start != NULL) {

		cel *j;

                for (j = l->start->next; j != NULL; j = j->next) {

			int key = j->content;
                        
			cel *i = j->last;

			while (i != NULL && i->content > key) {
				
				i->next->content = i->content;
				i = i->last;
			}

		        if (i != NULL)
				i->next->content = key;
			else
				l->start->content = key;
				 
		}
	}
}




