#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "functions.h"
#include "simpletest.h"

void sequential_test ()
{
        DESCRIBE ("Testes com o Bucket Sort que usa apenas uma thread");

        int v0 [1000], v1 [10000], v2 [20000];

        srand (time (NULL));

        int i, ok = 1;

	double tempo;
	clock_t tempo_ini, tempo_fim;

        for (i = 0; i < 1000; ++i)
                v0 [i] = rand ();

        for (i = 0; i < 10000; ++i)
                v1 [i] = rand ();

        for (i = 0; i < 20000; ++i)
                v2 [i] = rand ();

        WHEN ("Eu passo um vetor de 1000 elementos para o BS");
        THEN ("Ele deve ficar ordenado");

	tempo_ini=clock();

        bucket_sort (v0, 1000);

        for (i = 1; i < 1000; ++i)
                if (v0 [i - 1] > v0 [i])
                        ok = 0;

        isEqual (ok, 1, 1);

        ok = 1;

		tempo_fim=clock();
		tempo = difftime(tempo_fim,tempo_ini);
		printf("tempo: %g\n",((tempo*1000)/CLOCKS_PER_SEC));

        WHEN ("Eu passo um vetor de 10000 elementos para o BS");
        THEN ("Ele deve ficar ordenado");

	tempo_ini=clock();

        bucket_sort (v1, 10000);

        for (i = 1; i < 10000; ++i)
                if (v1 [i - 1] > v1 [i])
                        ok = 0;

        isEqual (ok, 1, 1);

        ok = 1;

		tempo_fim=clock();
		tempo = difftime(tempo_fim,tempo_ini);
		printf("tempo: %g\n",((tempo*1000)/CLOCKS_PER_SEC));

        WHEN ("Eu passo um vetor de 20000 elementos para o BS");
        THEN ("Ele deve ficar ordenado");

	tempo_ini=clock();

        bucket_sort (v2, 20000);

        for (i = 1; i < 20000; ++i)
                if (v2 [i - 1] > v2 [i])
                        ok = 0;

        isEqual (ok, 1, 1);

		tempo_fim=clock();
		tempo = difftime(tempo_fim,tempo_ini);
		printf("tempo: %g\n",((tempo*1000)/CLOCKS_PER_SEC));
}

void two_threads_test ()
{
	DESCRIBE ("Testes com o Bucket Sort que usa duas threads");

	int v0 [1000], v1 [10000], v2 [20000];

        srand (time (NULL));

        int i, ok = 1;

	double tempo;
	clock_t tempo_ini, tempo_fim;

        for (i = 0; i < 1000; ++i)
                v0 [i] = rand ();

	for (i = 0; i < 10000; ++i)
                v1 [i] = rand ();

	for (i = 0; i < 20000; ++i)
                v2 [i] = rand ();

        WHEN ("Eu passo um vetor de 1000 elementos para o BS");
	THEN ("Ele deve ficar ordenado");

	tempo_ini=clock();

	bucket_sort_pthreads (v0, 1000, 2);

        for (i = 1; i < 1000; ++i)
                if (v0 [i - 1] > v0 [i]) 
			ok = 0;
        
	isEqual (ok, 1, 1);

	ok = 1;

		tempo_fim=clock();
		tempo = difftime(tempo_fim,tempo_ini);
		printf("tempo: %g\n",((tempo*1000)/CLOCKS_PER_SEC));

	WHEN ("Eu passo um vetor de 10000 elementos para o BS");
        THEN ("Ele deve ficar ordenado");

	tempo_ini=clock();
	
        bucket_sort_pthreads (v1, 10000, 2);

        for (i = 1; i < 10000; ++i)
                if (v1 [i - 1] > v1 [i])
                        ok = 0;

        isEqual (ok, 1, 1);

	ok = 1;

		tempo_fim=clock();
		tempo = difftime(tempo_fim,tempo_ini);
		printf("tempo: %g\n",((tempo*1000)/CLOCKS_PER_SEC));

	WHEN ("Eu passo um vetor de 20000 elementos para o BS");
        THEN ("Ele deve ficar ordenado");

	tempo_ini=clock();
	
        bucket_sort_pthreads (v2, 20000, 2);

        for (i = 1; i < 20000; ++i)
                if (v2 [i - 1] > v2 [i])
                        ok = 0;

        isEqual (ok, 1, 1); 

		tempo_fim=clock();
		tempo = difftime(tempo_fim,tempo_ini);
		printf("tempo: %g\n",((tempo*1000)/CLOCKS_PER_SEC));
}

void four_threads_test ()
{
	DESCRIBE ("Testes com o Bucket Sort que usa quatro threads");

	int v0 [1000], v1 [10000], v2 [20000];

        srand (time (NULL));

        int i, ok = 1;

	double tempo;
	clock_t tempo_ini, tempo_fim;

        for (i = 0; i < 1000; ++i)
                v0 [i] = rand ();

	for (i = 0; i < 10000; ++i)
                v1 [i] = rand ();

	for (i = 0; i < 20000; ++i)
                v2 [i] = rand ();

        WHEN ("Eu passo um vetor de 1000 elementos para o BS");
	THEN ("Ele deve ficar ordenado");

	tempo_ini=clock();

	bucket_sort_pthreads (v0, 1000, 4);

        for (i = 1; i < 1000; ++i)
                if (v0 [i - 1] > v0 [i]) 
			ok = 0;
        
	isEqual (ok, 1, 1);

	ok = 1;

		tempo_fim=clock();
		tempo = difftime(tempo_fim,tempo_ini);
		printf("tempo: %g\n",((tempo*1000)/CLOCKS_PER_SEC));

	WHEN ("Eu passo um vetor de 10000 elementos para o BS");
        THEN ("Ele deve ficar ordenado");

	tempo_ini=clock();

        bucket_sort_pthreads (v1, 10000, 4);

        for (i = 1; i < 10000; ++i)
                if (v1 [i - 1] > v1 [i])
                        ok = 0;

        isEqual (ok, 1, 1);

	ok = 1;

		tempo_fim=clock();
		tempo = difftime(tempo_fim,tempo_ini);
		printf("tempo: %g\n",((tempo*1000)/CLOCKS_PER_SEC));

	WHEN ("Eu passo um vetor de 20000 elementos para o BS");
        THEN ("Ele deve ficar ordenado");

	tempo_ini=clock();

        bucket_sort_pthreads (v2, 20000, 4);

        for (i = 1; i < 20000; ++i)
                if (v2 [i - 1] > v2 [i])
                        ok = 0;

        isEqual (ok, 1, 1); 

		tempo_fim=clock();
		tempo = difftime(tempo_fim,tempo_ini);
		printf("tempo: %g\n",((tempo*1000)/CLOCKS_PER_SEC));
}

void eight_threads_test ()
{
	DESCRIBE ("Testes com o Bucket Sort que usa oito threads");

	int v0 [1000], v1 [10000], v2 [20000];

        srand (time (NULL));

        int i, ok = 1;

	double tempo;
	clock_t tempo_ini, tempo_fim;

        for (i = 0; i < 1000; ++i)
                v0 [i] = rand ();

	for (i = 0; i < 10000; ++i)
                v1 [i] = rand ();

	for (i = 0; i < 20000; ++i)
                v2 [i] = rand ();

        WHEN ("Eu passo um vetor de 1000 elementos para o BS");
	THEN ("Ele deve ficar ordenado");

	tempo_ini=clock();

	bucket_sort_pthreads (v0, 1000, 8);

        for (i = 1; i < 1000; ++i)
                if (v0 [i - 1] > v0 [i]) 
			ok = 0;
        
	isEqual (ok, 1, 1);

	ok = 1;

		tempo_fim=clock();
		tempo = difftime(tempo_fim,tempo_ini);
		printf("tempo: %g\n",((tempo*1000)/CLOCKS_PER_SEC));

	WHEN ("Eu passo um vetor de 10000 elementos para o BS");
        THEN ("Ele deve ficar ordenado");

	tempo_ini=clock();

        bucket_sort_pthreads (v1, 10000, 8);

        for (i = 1; i < 10000; ++i)
                if (v1 [i - 1] > v1 [i])
                        ok = 0;

        isEqual (ok, 1, 1);

	ok = 1;

		tempo_fim=clock();
		tempo = difftime(tempo_fim,tempo_ini);
		printf("tempo: %g\n",((tempo*1000)/CLOCKS_PER_SEC));

	WHEN ("Eu passo um vetor de 20000 elementos para o BS");
        THEN ("Ele deve ficar ordenado");

	tempo_ini=clock();

        bucket_sort_pthreads (v2, 20000, 8);

        for (i = 1; i < 20000; ++i)
                if (v2 [i - 1] > v2 [i])
                        ok = 0;

        isEqual (ok, 1, 1); 

		tempo_fim=clock();
		tempo = difftime(tempo_fim,tempo_ini);
		printf("tempo: %g\n",((tempo*1000)/CLOCKS_PER_SEC));
}

int main ()
{
	sequential_test ();
	two_threads_test ();
	four_threads_test (); 
	eight_threads_test ();
	
        return 0; 	
}
