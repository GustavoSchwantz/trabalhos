#ifndef _FUNCTIONS_H_
#define _FUNCTIONS_H_

#include "linked-list.h"

struct thread_data {
	LIST *buckets;
	int begin;
	int end;
};

void bucket_sort (int v[], int n);
void insertion_sort (LIST *l);
void bucket_sort_pthreads (int v[], int n, int num_threads);
void bucket_sort_omp (int v[], int n, int nt);
void *thread (void *thread_args);

#endif
