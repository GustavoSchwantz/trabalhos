#include <stdlib.h>
#include "functions.h"

void bucket_sort (int v[], int n)
{
	LIST buckets [n];

	int i;

	for (i = 0; i < n; ++i)
		list_init (&buckets [i]);

	for (i = 0; i < n; ++i)
		list_insert ( &buckets [ (int) ( n * (( (float) v [i] / RAND_MAX )) ) ],
			       	cell_factory ( v[i] ) );

	for (i = 0; i < n; ++i)
		insertion_sort (&buckets [i]);
	
	int j;

        for (i = 0, j = 0; i < n; ++i) {

		cel *c;

		for (c = buckets [i].start; c != NULL; c = c->next)  
			v [j++] = c->content;
                
		destroy_list (&buckets [i]);
	}	
}
