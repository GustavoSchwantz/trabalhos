#include <stdlib.h>
#include <pthread.h>
#include "functions.h"

void bucket_sort_pthreads (int v[], int n, int num_threads)
{
	LIST buckets [n];

	int i;

	for (i = 0; i < n; ++i)
		list_init (&buckets [i]);

	for (i = 0; i < n; ++i)
		list_insert ( &buckets [ (int) ( n * (( (float) v [i] / RAND_MAX )) ) ],
			       	cell_factory ( v[i] ) );
        
	// inicio da implementação paralela (parte do bucket_sort_parallel
	// diferente do bucket_sort)
	
	pthread_t threads [num_threads];
        pthread_attr_t attr;

	pthread_attr_init (&attr);
        pthread_attr_setdetachstate (&attr, PTHREAD_CREATE_JOINABLE);

	struct thread_data td_array [num_threads];
        int begin = 0;
	int end = n / num_threads;

	for (i = 0; i < num_threads; ++i) {
		td_array [i].buckets = buckets;
                td_array [i].begin = begin;
                td_array [i].end = end;

		begin = end;
		end += n / num_threads;
        }
        
	for (i = 0; i < num_threads; ++i) 
		pthread_create (&threads [i], &attr, thread, (void *) &td_array [i]);

	pthread_attr_destroy (&attr);

	for (i = 0; i < num_threads; ++i) 
		pthread_join (threads [i], NULL);
        
        // fim da implementação paralela
		
	int j;

        for (i = 0, j = 0; i < n; ++i) {

		cel *c;

		for (c = buckets [i].start; c != NULL; c = c->next)  
			v [j++] = c->content;
                
		destroy_list (&buckets [i]);
	}
}

void *thread (void *thread_args)
{
	struct thread_data *my_data;
	int i;

	my_data = (struct thread_data*) thread_args;
        
	for (i = my_data->begin; i < my_data->end; ++i)
                insertion_sort ( &(my_data->buckets [i]) );
}
