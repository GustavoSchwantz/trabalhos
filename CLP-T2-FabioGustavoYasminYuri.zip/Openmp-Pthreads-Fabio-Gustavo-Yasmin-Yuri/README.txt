Para compilar e rodar a versão com Pthreads, coloca no terminal:

gcc -pthread bucket-sort.c bucket-sort-pthreads.c insertion_sort.c linked-list.c teste-pthreads.c -o testep -lm
./testep

Para compilar e rodar a versão com OpenMP, coloca no terminal:

gcc -fopenmp bucket-sort-omp.c insertion_sort.c linked-list.c teste-omp.c -o teste-omp -lm 
./teste-omp 
